It is a backend CRUD Management System API, Using nodejs, express
Backend provides the functionalities of Creating and managing the essential data of a school
